package com.example;

public class MainTransfer {
    public static void main(String[] args) {
        BankService service = new BankService();
        service.transfer(1, 2, 500.0);
        System.out.println("Transaction completed successfully!");
    }
}
