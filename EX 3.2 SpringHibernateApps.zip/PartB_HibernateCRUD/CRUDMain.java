package com.example;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUDMain {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        // Create
        Student s1 = new Student("John Doe", "john@example.com");
        session.save(s1);

        // Read
        Student s2 = session.get(Student.class, 1);
        System.out.println("Student: " + s2.getName());

        // Update
        s2.setName("John Updated");
        session.update(s2);

        // Delete
        session.delete(s2);

        tx.commit();
        session.close();
    }
}
